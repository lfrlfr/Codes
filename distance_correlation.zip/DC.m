function [ dir D_YX  D_XY] = DC(X, Y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%causal_inference_DC: causal inference via estimating diatance correlations
%The function is designed for identifying the causal direction
% between the two discrete variables X and Y, it outputs "X causes Y" or "Y causes X" or "donot know".

%Input: 
%Column vectors containing the observations 
%    1. Variable X -- expected to be discrete variable
%    2. Variable Y -- expected to be discrete variable

%Output:
%The causal direction
%    1. X causes Y 
%    2. Y causes X 
%    3. don't know 

% Written by Furui Liu

% Reference: 
% @article{liu2016causal,
%   title={Causal Inference on Discrete Data via Estimating Distance Correlations},
%   author={Liu, Furui and Chan, Laiwan},
%   journal={Neural computation},
%   volume={28},
%   number={5},
%   pages={801--814},
%   year={2016},
%   publisher={MIT Press}
% }

% Contact email: furuiliu210@gmail.com
% Last update: Aug 18th, 2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

X = X - min(X) + 1;
Y = Y - min(Y) + 1;

%Construct the matrix recording the support of the joint ditribution of (Y,X) 
D=zeros(max(Y),max(X));
n= size(X,1);
for i=1:n,
    D(Y(i),X(i)) = D(Y(i),X(i))+1;
end

%Calculate the distance correlations
temp_1 = sum(D,1);
D1=D;
D1(:,temp_1==0) =[];
temp_1( temp_1==0) = [];  
D1 = D1./repmat(temp_1,size(D1,1),1);
temp_1 = temp_1 / sum(temp_1);
D_YX = distcorr(D1',temp_1');

temp_2 = sum(D,2);
D2=D;
D2(temp_2==0,:) =[];
temp_2( temp_2==0) = []; 
D2 = D2./repmat(temp_2,1,size(D2,2));
temp_2 = temp_2 / sum(temp_2);
D_XY=distcorr(D2,temp_2);

%Infer the causal directions
dir = -1;
epsilon_estimated  =D_XY - D_YX;

if(epsilon_estimated > 0)
     dir=1;
     disp('    X causes Y'); 
elseif (epsilon_estimated <  0)
    dir=0;
     disp('    Y causes X'); 
else
     disp('    do not know');
end
end

