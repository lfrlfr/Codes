clear;
disp('loading mean daily temperature dataset......');
load('mean daily temperature dataset.txt');
disp('X: day of the year');
disp('Y: temperature');
disp('ground truth: X causes Y');
disp('desicion made by distance correlation:');
X=ceil(mean_daily_temperature_dataset(:,1)/7);
Y=round(mean_daily_temperature_dataset(:,2));
DC(X,Y);

