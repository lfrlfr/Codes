clear;

%try mean daily temperature dataset
disp('loading mean daily temperature dataset......');
load('mean_daily_temperature_dataset.txt');
disp('X: day of the year');
disp('Y: temperature');
disp('ground truth: X causes Y');
disp('desicion made by support analysis:');
SA(mean_daily_temperature_dataset(:,1),round(mean_daily_temperature_dataset(:,2)));

disp(' ');

%try milk protein trial dataset 
disp('loading milk protein trial dataset......');
load('milk_protein_trial_dataset.txt');
disp('X: time to take measurement');
disp('Y: protein content')
disp('ground truth: X causes Y');
disp('desicion made by support analysis:');
SA(milk_protein_trial_dataset(:,1),round(10*milk_protein_trial_dataset(:,2)));