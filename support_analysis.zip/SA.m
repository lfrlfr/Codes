function SA( X, Y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SA: support analysis
%The function is designed for identifying the causal direction
% between the two discrete variables X and Y, it outputs "X causes Y" or "Y causes X" or "donot know".

%Input: 
%Column vectors containing the observations 
%    1. Variable X -- expected to be discrete variable
%    2. Variable Y -- expected to be discrete variable

%Output:
%The causal direction
%    1. X causes Y 
%    2. Y causes X 
%    3. don't know 

% Written by Furui Liu, the Chinese University of Hong Kong
% Reference: 
%[1] Furui Liu, Laiwan Chan. "Causal discovery on discrete data with extensions to mixtur model". 
%ACM Transactions on Intelligent Systems and Technology, Vol. 7, No. 2, 2016.

% Contact email: furuiliu210@gmail.com
% Last update: Dec 18th, 2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%Normalize the vaiables to be positive integers
X = X - min(X) + 1;
Y = Y - min(Y) + 1;

%Construct the matrix recording the support of the joint ditribution of (Y,X) 
D=zeros(max(Y),max(X));
n= size(X,1);
for i=1:n,
    D(Y(i),X(i)) = 1;
end

%Calculate the variation C_YX and C_XY 
temp_1 = sum(D,1);
temp_1( temp_1==0) = [];       
C_YX = max(temp_1) - min(temp_1);
temp_2 = sum(D,2);
temp_2( temp_2==0) = []; 
C_XY = max(temp_2) - min(temp_2);

%Discover the causal direction
if(C_YX < C_XY)
     disp('   X causes Y'); 
elseif (C_YX > C_XY)
     disp('   Y causes X'); 
else
     disp('   do not know the direction');
end

        

end

